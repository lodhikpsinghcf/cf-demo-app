# ContentFlow JavaScript SDK 2.1.0

One package serves Web, React and React Native. This release is distributed as `contentflow-sdk-2.1.0.tgz`; registry publication is not assumed. Obtain the versioned archive and checksum from [GitHub Releases](https://github.com/ContentflowSystem/contentflow/releases/tag/sdk-v2.1.0), then install it in your application:

```sh
npm install ./vendor/contentflow-sdk-2.1.0.tgz
```

Supported exports:

| App | Import |
|---|---|
| JavaScript/TypeScript core | `@contentflow/sdk` |
| Browser | `@contentflow/sdk/web` |
| React | `@contentflow/sdk/react` |
| React Native | `@contentflow/sdk/react-native` |

There is no separate `@contentflow/react-native` package in this release. React is supplied by the host app. React Native also requires `@react-native-async-storage/async-storage`; install the version compatible with your app and rebuild its native projects. `react-native-sse` is optional: without an EventSource adapter, React Native uses polling.

## Initialize and identify

Use the workspace's **publishable SDK key** from ContentFlow developer settings. Use the test key for validation and the live key only for the intended production build; the server resolves the environment from the key. Never put dashboard credentials, write keys or signing secrets into an app. There is no client-side flag that changes a live key into a test key.

```ts
import { createCFClient } from '@contentflow/sdk/web';

const client = createCFClient({
  baseUrl: 'https://app.contentflow.click/sdk/v1',
  tenantId: CONTENTFLOW_WORKSPACE_ID,
  publicKey: CONTENTFLOW_PUBLISHABLE_KEY,
  deviceId: EXISTING_INSTALLATION_ID, // preserve during migration; omit to generate/persist
  userId: YOUR_SIGNED_IN_USER_ID,     // omit for anonymous installs
  locale: 'ar',
  consent: false,                    // analytics consent, not push consent
  onEventsDropped: reportRejectedEvents,
  onEventsUncertain: reconcileUncertainDelivery,
});

try {
  const receipt = await client.identify({traits: {appLanguage: 'ar'}});
  // receipt.results?.identity reports identified, anonymous, or unchanged.
  await client.start();              // identify, cached paint, sync, strings, polling/SSE
} catch (error) {
  // Keep bundled UI fallbacks and show an integration error in your diagnostics.
}
```

The legacy base `https://app.contentflow.click/api/v1/sdk` is routed to the same public gateway. Set a base URL through `/sdk/v1` or `/api/v1/sdk`, without a trailing operation such as `/sync`. New objects use their own state; maintain one client per active app/workspace/account. Await explicit `identify()` if startup failure must block your flow: `start()` keeps offline UI available and logs refresh failures.

## Live status

`start()` silently falls back to polling when there's no `EventSource` on the platform, and reconnects a dropped stream forever behind the scenes — none of that was visible without `debug: true`. Observe it directly instead:

```ts
client.subscribeLiveStatus((live) => {
  if (live.mode === 'poll') console.warn('not streaming:', live.reason);
});
const live = client.getLiveStatus(); // { mode, state, reason?, since, lastError? }
```

`mode` is `'stream' | 'poll' | 'off'`; `state` is `'connecting' | 'connected' | 'reconnecting' | 'polling' | 'stopped'`; `reason` explains it (`stream_unsupported`, `stream_error`, `live_disabled`, `backgrounded`, `disposed`). `subscribeLiveStatus` fires immediately with the current status, then on every change; `since` only moves when mode/state/reason change, so "reconnecting since" survives a burst of failures. Also available as `CFConfig.onLiveStatus` and, for React/React Native, `useLiveStatus()` from `@contentflow/sdk/react` / `@contentflow/sdk/react-native`. None of this depends on `debug`.

## Error handling

Reads that used to fail silently are now typed and observable. A misconfigured `baseUrl` — the response doesn't look like a ContentFlow delivery API — surfaces as `CFInvalidBaseUrlError` (`code: 'invalid_base_url'`) on every relevant surface at once, never re-wrapped:

```ts
client.subscribeErrors((e) => report(e));            // e.code === 'invalid_base_url'
new CFClient({ ..., onError: (error) => report(error) });
client.getLiveStatus().lastError;                     // the same instance, read back later

try {
  await client.fetchBlock('home_banner');
} catch (e) {
  if (e instanceof CFInvalidBaseUrlError) showSetupHelp(e.baseUrl);
}
```

| Call | on a wrong `baseUrl` |
|---|---|
| `fetchBlock()` | **rejects** with `CFInvalidBaseUrlError` |
| `getStrings()` | **rejects**, after cold-start fallback tiers are applied |
| `getConsentConfig()` | **rejects** (as before) |
| `sync()` / `start()` | resolve with last-good content, and **report** the error |

Only this named diagnosis is reported this way — an ordinary transient outage (a 503, a timeout) keeps last-good content and is logged once per episode, not surfaced through `onError`, or every poll tick would fire it. `sync()` never throws, because it's also the poll tick. `subscribeErrors` does not replay past errors on subscribe; read `getLiveStatus().lastError` for the last one.

Every other write/read failure the SDK raises is one of: `CFError` (base class, has `.code`), `CFWriteFailedError`, `CFPartialWriteError`, `CFUnknownConsentPresetError`, `CFConsentConfigUnavailableError`, `CFLocalesUnavailableError`, `CFMalformedResponseError` — match on `instanceof` or `.code` rather than the message text.

## Consent, push and account lifecycle

```ts
// Use your app's recorded user choices; do not blindly grant either consent.
await client.setConsent(analyticsGranted);
await client.setChannelConsent(YOUR_SIGNED_IN_USER_ID, {push: pushGranted});
const deviceConsent = await client.setChannelConsent({push: pushGranted});

// Obtain the OS token and notification permission through APNs/FCM/HMS in your app.
await client.registerPush({token: OS_PUSH_TOKEN, platform: 'ios', provider: 'apns'});
const linkage = await client.registerPushWithReceipt({token: OS_PUSH_TOKEN, platform: 'ios', provider: 'apns'});
// Call again on token refresh. Registration does not grant push consent.

// On withdrawal, confirm the server-side channel revocation first.
await client.setChannelConsent(YOUR_SIGNED_IN_USER_ID, {push: false});
await client.unregisterPush();       // idempotent, removes only this installation's token

// On sign-out, unlink identity and remove this device's profile token together.
await client.logout();
```

Android uses `platform: 'android', provider: 'fcm'`. Huawei uses `provider: 'hms'` with `hmsConfig.appId`; Web uses `provider: 'web_push'`. The SDK does not create APNs/FCM/HMS credentials, ask for OS permission, deliver background messages, or register a browser service worker. Configure those in the host app. Browser subscription/provider setup is application-owned.

`setChannelConsent(username, channels)` writes profile consent; `setChannelConsent(channels)` writes device-only consent and returns the typed device/consent receipt. Device-level analytics consent and channel consent are independent. `registerPushWithReceipt` exposes the server linkage status while the compatibility `registerPush` method still resolves to `void`. Unregistering or logging out does not revoke channel consent. Every failed write rejects, including HTTP 200 containing `success:false`; keep the last confirmed setting until a write succeeds. A timeout cannot prove whether a write reached the server, so reconcile/retry idempotent consent/token operations.

Before signing a different user into the installation, inspect the receipt from `setUserId(newUserId)`; `identified`, `anonymous`, and `unchanged` are distinct outcomes. On sign-out, call `logout()` with the same client/device. A 207 `PUSH_LINKAGE_INCOMPLETE` may still prove the identity is anonymous or identified; the SDK keeps that confirmed identity state and throws a `partial_write` error whose `receipt` identifies the incomplete push step. A network/500 outcome clears old personalized content and events but does not claim durable detachment. Account changes and same-user trait/segment changes invalidate every locale/namespace generation before late reads can land. Never reuse one client between server-side requests from different people.

A server can suppress a recipient without another app launch once it has received a revocation through a supported server/dashboard channel. It cannot infer a choice made only on an offline device. Push-provider credentials, dispatch-time revocation and on-device receipt require deployment/device verification outside SDK unit tests.

### Consent presets

`GET /sdk/consent/config/:preset` answers the shape a consent screen for one regulated industry should offer — which channels are required versus optional, the default messaging topics, and the legal framework it's built against. There are exactly seven valid ids, and no `default`: `banking_ksa`, `insurance_ksa`, `healthcare_ksa`, `travel_ksa`, `retail_ksa`, `food_delivery_ksa`, `fintech_ksa`.

```ts
import { consentPathsToConfig } from '@contentflow/sdk';

const preset = await client.getConsentConfig('banking_ksa');
// { preset: 'banking_ksa', industry: 'banking', region: 'SA',
//   required: ['channels.push'], optional: ['marketing.promotional'],
//   defaultTopics: [...], availableTopics: [{id, name, nameAr?, required}, ...],
//   legalFramework: 'SAMA + PDPL' }

await client.requestConsent({ preset: preset.preset, ...consentPathsToConfig(preset.required) });
```

`required`/`optional` are dotted paths into the consent state (`channels.push`, `marketing.transactional`, `marketing.serviceUpdates`, `marketing.promotional`, `marketing.thirdPartyOffers`, `location`) — the same paths `client.hasConsent(path)` takes, not booleans or channel names. `consentPathsToConfig(paths, value?)` turns a list of them into the flat `ConsentConfig` the write methods (`setConsent`, `requestConsent`, `setChannelConsent`) take; an unrecognised path is ignored rather than guessed at.

**Reading a preset never grants, revokes, or otherwise changes anyone's consent** — that only happens through an explicit write call. `id`/`name` are deprecated aliases of `preset`, kept so 1.1.0 callers keep working. An unknown preset id throws `CFUnknownConsentPresetError` (carries `preset` and `availablePresets`); a service failure throws `CFConsentConfigUnavailableError`; a malformed 200 body throws `CFMalformedResponseError`.

## Content, campaigns and localization

```ts
const blocks = await client.sync();
const welcome = client.getBlock('welcome');
const title = welcome?.get('title') ?? 'Welcome';
const cards = welcome?.getCollection('cards') ?? [];
const campaigns = await client.getCampaigns('home_banner');
await client.getStrings('home');
const label = client.t('welcome', 'Welcome');
await client.setLocale('ar');
```

The server resolves locale using `?locale=` and `Accept-Language`. The SDK sends both. `?lang=` and `X-CF-Locale` are not the SDK contract; unsupported aliases may be warned about by the gateway. Campaign evaluation uses public `POST /campaigns`; locale-keyed campaign content resolves exact locale, then neutral language (`ar-SA` to `ar`), then the document's English fallback. Sync and strings have independent validators; strings additionally isolate namespaces. A valid payload without an ETag is processed and clears the previous validator. HTTP 304 uses only the matching cached payload. Failed/malformed reads retain last-good content. Switching locale clears the previous locale's view so it cannot masquerade as the requested language during an outage. When Arabic is absent or withheld, the server can return workspace source strings or block base source fields, including English. An app-supplied string fallback applies only when the delivered key is absent; it does not replace server-supplied source text. The SDK never invents a translation.

Block values are keyed by tags such as `#title`. `get('title')` normalizes the prefix. Arbitrary values and collection cards remain available to app-owned renderers. Campaign placement and segmentation are evaluated by the server. React exports `CFProvider`, `useCFBlock`, `useCFBlocks`, `useCFString`, `useCFTranslations`, and `useCFCampaigns`. React Native additionally exports `CFBanner` and `CFCampaignBanner`.

### `fetchBlock` scoped overrides

`fetchBlock(key, { locale?, deviceId? })` reads one block for another locale or another install — a preview screen, a "see it in Arabic" toggle, a support tool — without the global side effects of `setLocale()` (which re-syncs the whole app and re-renders every screen):

```ts
const arabic = await client.fetchBlock('home_banner', { locale: 'ar' });
const asUser = await client.fetchBlock('home_banner', { deviceId: supportTicket.deviceId });
```

An override is sent for that one request only: it never assigns `this.locale`, the device id, the audience scope or the identity, and is never written into the block cache, the sync list, or the persisted cache — the next ordinary request carries the install's own identity again. Called with no `options`, the call is byte-for-byte what it always was.

### Locales

`client.getLocales()` lists every locale the workspace has configured, so a client can build a language picker without hardcoding one:

```ts
const { locales, sourceLocale } = await client.getLocales();
const offerable = locales.filter((l) => l.coverage >= 80);
client.getCachedLocales(); // last successfully-read catalog, or undefined if never read
```

Each entry carries `code`, `name`, `native`, `rtl`, `isSource`, and `coverage` (a locale can be configured at 0% coverage — it's a promise the workspace intends to serve that language, not that any string in it is translated yet). It's ETag-revalidated with its **own** validator, independent of the sync/strings validators, and deliberately survives identity changes — which languages a workspace publishes doesn't depend on who's logged in. An empty `locales` list is a valid answer. A gateway with no `/locales` route, or a `LOCALE_CATALOG_UNAVAILABLE` failure, throws `CFLocalesUnavailableError` — the SDK never invents `en`/`ar` in its place.

## Sensors and analytics

```ts
client.trackImpression(welcome); // only when a block exists and is actually visible
client.trackTap(welcome);
client.trackCampaignImpression(campaigns[0]); // only after rendering a real campaign
await client.flush();
```

Use real rendered objects and guard missing content in application code. Automatic string usage signals are gated by delivered `smartKeys`; Web also supports `bindStringSensors` for viewport/interaction bindings. Native host visibility is application-owned; React hooks report usage/mount, not proof that the user saw a pixel. Analytics require explicit recorded analytics consent.

### Pre-consent analytics policy

> Before analytics consent is granted, the SDK does not collect, queue, retain or later replay events. Nothing is held back to be sent once consent arrives: a consent grant is not retroactive, and an event the user had not yet agreed to is not one the SDK gets to keep.

That refusal used to be a bare, silent `return` — an integrator seeing no analytics couldn't tell a missing `setConsent(true)` from a wrong key or a wrong `baseUrl`. Every pre-consent refusal is now reported through the existing drop machinery with a discriminator:

```ts
client.subscribeEventDrops((info) => {
  // { accepted: 0, dropped: 1, total: 1, allDropped: true,
  //   eventTypes: ['tap'], dropReasons: { consent_not_granted: 1 }, source: 'local' }
});
```

`EventDropInfo.source` / `EventsDroppedInfo.source` is `'local' | 'server'`: `'local'` also marks the SDK's other own-side drops (queue full, identity changed before delivery, consent revoked); a server-reported drop says `'server'`. Reports from older SDKs carry no `source` — its absence means nothing either way. Covers every entry point: `track`, `trackImpression`, `trackTap`, `trackConversion`, `trackCtaClick`, `trackDismiss`, the `trackCampaign*` family, the industry helpers, and `trackString`. Drops for `disposed` and an in-flight identity change stay silent on purpose (the identity transition already emits its own report).

Identity and consent writes are sent in public API invocation order. An analytics revocation takes effect locally before the request: it stops new collection and purges pending in-memory and persisted known-offline events even when the device is offline or the server write later fails. Treat that failure as a server reconciliation requirement while keeping local collection disabled. An analytics grant becomes active only when the identify response explicitly confirms `consent: true`; a server `consent: false` echo remains authoritative, and an older in-flight grant cannot restore consent after a newer revocation.

Batches are bounded to 100 by `eventBatchSize`. A partial aggregate ACK reports `accepted`, `dropped`, and arbitrary `dropReasons` keys, then consumes the batch because the response cannot identify which items are safe to retry. If `accepted + dropped` does not equal the submitted count, `onEventsUncertain` receives `unaccounted`; the whole ACK is still consumed to avoid replaying accepted items. `device_not_identified` means gateway device state was unavailable, including a cache read failure; it does not prove the durable profile is absent. A production HTTP 202 currently means local gateway queue acceptance, **not confirmed durable Kafka or ClickHouse storage**. Local impression deduplication is per client session; no server exactly-once guarantee exists. Custom analytics names preserve case but empty/control-character names and sign-up/sign-in names routed through `/events` are rejected; identity events use `trackEvent`/`trackSignUp`/`trackSignIn`.

Default `eventRetryPolicy: 'report'` reports timeout/network/5xx uncertainty with `onEventsUncertain` and does not automatically replay the batch. Retain that diagnostic in your app's reconciliation flow. `eventRetryPolicy: 'at-least-once'` explicitly permits retry and possible duplicate counters; use it only with that tradeoff accepted. Explicit 429 refusals remain queued in memory for this client session.

With `enableOfflineQueue: true`, batches handed off while connectivity is already known offline are written to the scoped storage outbox before they are consumed from the behavioral queue; storage denial falls back to memory with a warning. Ordinary pending sub-batches, periodic-flush batches and online 429 retry batches remain memory-only and can be lost on process death. This SDK does not claim a fully durable event outbox. Capacity, expiry and retry-limit removals are reported through `onEventsDropped`. Browser termination may prevent a final network flush; call `flush()` at meaningful app boundaries. This is not a financial audit log.

When the platform reports background state, the client closes SSE, stops polling and pauses periodic event flushes after requesting one boundary flush. Foreground state forces one blocks + strings reconciliation before polling and SSE resume. `dispose()` aborts outstanding requests, stops polling/stream/lifecycle work, and requests a final best-effort event flush. Await `flush()` first when you must observe the completed attempt. Do not enqueue more events after disposal.

## Theming

A typed color-field reader and a small theme helper built on the existing block model — not a UI framework, no components, no CSS-in-JS, no design-token system. Turns a block's color values into typed `CFColor` objects (`hex`, `rgba`, `raw`):

```tsx
import { useCFTheme } from '@contentflow/sdk/react'; // or '@contentflow/sdk/react-native'

function AppShell() {
  const { theme, loading } = useCFTheme(
    'brand_theme',
    { primary: '#brand_primary', accent: '#brand_accent' },
    { fallback: { primary: '#5b57e0', accent: '#f0654a' } },
  );
  if (loading) return null;
  return <div style={{ '--cf-primary': theme.colors.primary?.hex }}>{/* ... */}</div>;
}
```

Core functions are pure and synchronous: `parseCFColor(value)` parses one color value (hex `#rgb`/`#rgba`/`#rrggbb`/`#rrggbbaa`, `rgb()`/`rgba()` in comma or modern space form, or a defensively-unwrapped `{hex: '...'}`/`{value: '...'}` object) and never throws — anything it can't parse returns `undefined`. `getBlockColor(block, tag)` reads one color field by tag; `getBlockColors(block)` returns every color on the block whose tag ends with `_color`/`_colour` or starts with `#color_`. `themeFromBlock(block, mapping, fallback?)` maps named theme slots to block tags, falling back to a supplied hex per slot; `block` may be `undefined` and it still returns a stable shape. `useCFTheme` is built directly on `useCFBlock`, so it follows the same live-update/cache semantics, and does **not** itself fire an impression event (reading a theme isn't the same as rendering the block's content).

## Expo push (`@contentflow/sdk/expo`)

Optional helper for Expo/React Native apps using `expo-notifications`. Dependency-injected — this subpath never imports `expo-notifications` itself, so it builds and typechecks with nothing installed; you pass your own copy of the module in.

```ts
import * as Notifications from 'expo-notifications';
import { registerExpoPush, unregisterExpoPush } from '@contentflow/sdk/expo';

const result = await registerExpoPush(client, Notifications, { requestPermission: true });
switch (result.status) {
  case 'registered': /* result.provider, result.receipt */ break;
  case 'permission_denied': /* result.canAskAgain */ break;
  case 'permission_not_requested': break;
  case 'unsupported_token': break; // e.g. web, or an Expo relay token
  case 'failed': /* result.error */ break;
}

await unregisterExpoPush(client); // later — sign-out, notifications disabled, etc.
```

Expo's push stack produces two token kinds; only one is usable by ContentFlow:

| | Expo push token | Native device token |
|---|---|---|
| From | `Notifications.getExpoPushTokenAsync()` | `Notifications.getDevicePushTokenAsync()` |
| Shape | `{ type: 'expo', data: 'ExponentPushToken[...]' }` | `{ type: 'ios' \| 'android', data: '<APNs/FCM token>' }` |
| Delivered by | Expo's own push relay service | APNs (iOS) / FCM (Android) directly |
| Accepted by ContentFlow | **No** | **Yes** |

`registerExpoPush` only ever calls `getDevicePushTokenAsync()`; it never calls `getExpoPushTokenAsync()`, and rejects an `ExponentPushToken[...]`-shaped token as `unsupported_token` if one turns up, since ContentFlow's backend delivers through APNs/FCM/HMS directly, not Expo's relay. A `web` (`PushSubscription`-shaped) token is also rejected — that's the separate `web_push` provider. HMS (Huawei) devices aren't reachable through Expo at all: there's no Expo API for a Huawei Push Kit token, so register those with `client.registerPushWithReceipt({ provider: 'hms', hmsConfig: { appId }, ... })` directly.

Getting `expo-notifications` permission only means the OS will let your app show notifications — it says nothing about whether ContentFlow is allowed to message this person over the push channel. That's a separate, explicit decision made with the consent APIs (`client.setChannelConsent({ push: true })`, `requestConsent`, or a consent preset); this helper never calls a consent API. Prefer exceptions at the call site? Use `registerExpoPushOrThrow`, which returns only the `'registered'` case and throws on everything else.

## Samples and validation

The release's sample archive contains `examples/web-app`, `examples/react-app` and `examples/react-native-app`. Build the SDK first (`npm ci && npm run build` in `contentflow-sdk/`), then run `npm install` and `npm run build` in the sample. `npm start` starts Web/React on localhost; the React Native sample uses Expo. Samples start disconnected, contain no credentials and require explicit connection with your test workspace. Local tests never contact a tenant.

Build from source: `npm ci`, `npm run typecheck`, `npm test`. Contract tests consume the sibling `sdk-release/fixtures/runtime-contract.json` included in the source/sample bundle. The release manifest records exactly which native builds and runtime tests were performed; a Metro bundle is not an APNs/FCM delivery test.

## Compatibility and limits

See `CHANGELOG.md` and the release-wide `API-CONTRACT.md`. This release validates the customer runtime path: identity, consent, blocks, strings, campaign delivery, analytics/sensors, token registration/removal and lifecycle behavior. Live refresh uses SSE where the adapter supplies it, with polling as fallback; neither is a durable message stream. Cached content is stale-while-revalidate and the delivery wire carries no cache expiry deadline, so the SDK cannot enforce one offline. Existing advanced location, industry-profile, KYC and sponsored helpers are not a claim of end-to-end backend/provider certification. APNs/FCM/HMS delivery and device receipt still require vendor/device testing. The optional JavaScript HMAC/pinning flags now fail explicitly because fetch never implemented those guarantees. Default cache storage is not encrypted; provide appropriate host storage when needed. Keep app UI fallbacks.
